

function welcomeAlert(){
	alert("If you're seeing this, your server sent functions.js!")
}

